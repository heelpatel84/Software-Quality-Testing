﻿///I, Heel Patel, 000898350 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;
using System.Collections.Generic;

namespace Assignment3
{
    /// <summary>
    /// Library of statistical functions using Generics for different statistical calculations.
    /// See http://www.calculator.net/standard-deviation-calculator.html for sample standard deviation calculations.
    /// 
    /// @author Joey Programmer
    /// </summary>
    public class A3
    {
        // Applied Coding Standards:
        // 1. DO use Pascal Casing for class names and method names.
        // 2. DO use camel casing for method parameters and local variables.
        // 3. DO NOT use underscores in identifiers.
        // 4. DO use braces ({}) for all control flow statements.

        /// <summary>
        /// Calculates the average of a list of double values.
        /// </summary>
        /// <param name="values">The list of double values.</param>
        /// <param name="includeNegative">Include negative values in the calculation.</param>
        /// <returns>The average of the list.</returns>
        /// <exception cref="ArgumentException">Thrown when the list contains no positive values.</exception>
        public static double Average(List<double> values, bool includeNegative)
        {
            double sum = Sum(values, includeNegative);
            int count = 0;
            for (int i = 0; i < values.Count; i++)
            {
                if (includeNegative || values[i] >= 0)
                {
                    count++;
                }
            }
            if (count == 0)
            {
                throw new ArgumentException("The list contains no values greater than or equal to 0.");
            }
            return sum / count;
        }

        /// <summary>
        /// Calculates the sum of a list of double values.
        /// </summary>
        /// <param name="values">The list of double values.</param>
        /// <param name="includeNegative">Include negative values in the calculation.</param>
        /// <returns>The sum of the list.</returns>
        /// <exception cref="ArgumentException">Thrown when the list is empty.</exception>
        public static double Sum(List<double> values, bool includeNegative)
        {
            if (values.Count == 0)
            {
                throw new ArgumentException("The list cannot be empty.");
            }

            double sum = 0.0;
            foreach (double val in values)
            {
                if (includeNegative || val >= 0)
                {
                    sum += val;
                }
            }
            return sum;
        }

        /// <summary>
        /// Calculates the median of a list of double values.
        /// </summary>
        /// <param name="data">The list of double values.</param>
        /// <returns>The median of the list.</returns>
        /// <exception cref="ArgumentException">Thrown when the list is empty.</exception>
        public static double Median(List<double> data)
        {
            if (data.Count == 0)
            {
                throw new ArgumentException("The list cannot be empty.");
            }

            data.Sort();
            double median = data[data.Count / 2];
            if (data.Count % 2 == 0)
            {
                median = (data[data.Count / 2] + data[data.Count / 2 - 1]) / 2;
            }

            return median;
        }

        /// <summary>
        /// Calculates the standard deviation of a list of double values.
        /// </summary>
        /// <param name="data">The list of double values.</param>
        /// <returns>The standard deviation of the list.</returns>
        /// <exception cref="ArgumentException">Thrown when the list has less than two values.</exception>
        public static double StandardDeviation(List<double> data)
        {
            if (data.Count <= 1)
            {
                throw new ArgumentException("The list must contain at least two values.");
            }

            int n = data.Count;
            double sum = 0;
            double average = Average(data, true);

            for (int i = 0; i < n; i++)
            {
                double value = data[i];
                sum += Math.Pow(value - average, 2);
            }
            double standardDeviation = Math.Sqrt(sum / (n - 1));
            return standardDeviation;
        }

        /// <summary>
        /// Main method to test the statistical functions.
        /// </summary>
        /// <param name="args">Command-line arguments.</param>
        static void Main(string[] args)
        {
            Console.WriteLine("Sample Output for Statistical Functions Library");
            List<double> testData = new List<double> { 2.2, 3.3, 66.2, 17.5, 30.2, 31.1 };
            Console.WriteLine("The sum of the array = {0}", Sum(testData, true));
            Console.WriteLine("The average of the array = {0}", Average(testData, true));
            Console.WriteLine("The median value of the data set = {0}", Median(testData));
            Console.WriteLine("The sample standard deviation of the test set = {0}\n", StandardDeviation(testData));
            Console.WriteLine("Press Enter Key To Exit...");
            Console.ReadLine();
        }
    }
}
